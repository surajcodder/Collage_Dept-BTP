sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("teacher.ext.view.Attachment",{})});
//# sourceMappingURL=Attachment.controller.js.map