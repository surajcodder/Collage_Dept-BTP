sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("teacher.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);